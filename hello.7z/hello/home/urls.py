from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import path,include
from home import views

urlpatterns = [
    path('', views.index, name='home'),
    path('map_links', views.Dashboard, name='map_links'),
    path('current_map_analysis', views.current_map_analysis, name='current_map_analysis'),
    path('compare', views.compare, name='compare'),
    path('Dashboard', views.Dashboard, name='RADashboard'),
    path('getMapReportPath', views.getMapReportPath, name='getMapReportPath'),
    path('current_map_report', views.current_map_report, name='current_map_report'),
    path('previous_map_report', views.previous_map_report, name='previous_map_report'),

]