from django.http.request import HttpRequest
from django.shortcuts import render, HttpResponse, redirect
import os
import folium
import pandas as pd
import json
from django.conf import settings
from os import listdir
from os.path import isfile, join

## Global variables
v1path = ""
v2path = ""

# Create your views here.
def index(request):
    context = {
        'variable': "This is sent"
    }
    return render(request, 'index1.html', context)

def current_map_analysis(request):
    shp_dir = os.path.join(os.getcwd(),'media', 'shp')
    #m = folium.Map(location=[-16.22, -71.59], zoom_start=10)
    m = folium.Map()
    sytle_basin = {'fillColor': '#228B22','color': '#228B22'}
    sytle_river = {'color': 'blue'}
    folium.GeoJson(os.path.join(shp_dir, 'HAFMAP-468_v31_Demo.geojson'), name='Demo').add_to(m)
    m = m._repr_html_()
    context = {'my_map': m}

    return render(request, 'current_map_analysis.html', context)

def previous_map_analysis(request):
    return render(request, 'previous_map_analysis.html')

def importData(request):
    if request.method == "POST":
        file = request.FILES['files']
        path = file.file
    return path

def Dashboard(request):
    #path = importData(request)
    #context = {'path': path}
    return render(request, 'Dashboard.html')

def current_map_report(request):
    global v1path
    geojsonfileList = []
    geojsonTableList = []
    if v1path != "":
        fileList = [f for f in listdir(v1path) if isfile(join(v1path, f))]
        for file in fileList:
            if file.endswith(".geojson"):
                geojsonfileList.append(join(v1path, file))
    m = folium.Map()
    for geojsonfile in geojsonfileList:
        folium.GeoJson(geojsonfile, name=geojsonfile.split('\\')[-1]).add_to(m)
    m = m._repr_html_()
    for geojsonfile in geojsonfileList:
        contents = open(geojsonfile).read()
        data = json.loads(contents)
        df = pd.json_normalize(data["features"])
        df_columns = ['type', 'properties.tileid', 'properties.roadid','properties.lanegroup_id', 'properties.lane_id',
        'properties.boundary_id', 'properties.boundary_element_id','properties.error_type',
        'properties.status', 'properties.error_description',
        'properties.featureid', 'properties.featuretype', 'properties.motorway',
        'properties.controlled_access',
        'geometry.type', 'geometry.coordinates']
        df_columns_filtered = []
        for column in df_columns:
            if column in df.columns:
                df_columns_filtered.append(column)
        df = df[df_columns_filtered]
        geojsonTableList.append(df)
    #coords = 'geometry.coordinates'
    #df2 = (df[coords].apply(lambda r: [(i[0],i[1]) for i in r[0]])
    #       .apply(pd.Series).stack()
    #       .reset_index(level=1).rename(columns={0:coords,"level_1":"point"})
    #       .join(df.drop(coords,1), how='left')).reset_index(level=0)

    #df2[['lat','long']] = df2[coords].apply(pd.Series)

    #json_records = df.reset_index().to_json(orient='records')
    #arr = []
    #arr = json.loads(json_records)
    labels = []
    for geojsonfile in geojsonfileList:
        labels.append(geojsonfile.split('\\')[-1])
    data = []
    #labels = ['HAFMAP-468_v31']
    for geojsontable in geojsonTableList:
        data.append(len(geojsontable))
    
    df = geojsonTableList[0]
    df_name = ''
    index = 0
    if request.method == 'POST':
        df_name = request.POST.get('showrecords')
        index = labels.index(df_name)
        df = geojsonTableList[index]
    print("df name is " + df_name)
    print("df index is " + str(index))
    print("df length is " + str(data[index]))
    contextt = {
                'df_dict': df.to_dict(),
                'df_rec': df.to_dict(orient='records'),
                'df_list' : geojsonTableList,
                'labels':labels,
                'data':data,
                'my_map': m,
                }

    return render(request, 'current_map_report.html', contextt)
 
def previous_map_report(request):
    shp_dir = os.path.join(os.getcwd(),'media', 'shp')
    m = folium.Map()
    folium.GeoJson(os.path.join(shp_dir, 'HAFMAP-468_v37_Demo.geojson'), name='Demo').add_to(m)
    m = m._repr_html_()
    contents = open(os.path.join(shp_dir, 'HAFMAP-468_v37_Demo.geojson')).read()
    data = json.loads(contents)
    df = pd.json_normalize(data["features"])
    df_columns = ['type', 'properties.tileid', 'properties.roadid','properties.lanegroup_id', 'properties.lane_id',
       'properties.boundary_id', 'properties.boundary_element_id','properties.error_type',
       'properties.status', 'properties.error_description',
       'properties.featureid', 'properties.featuretype', 'properties.motorway',
       'properties.controlled_access',
       'geometry.type', 'geometry.coordinates']
    df = df[df_columns]
    coords = 'geometry.coordinates'
    df2 = (df[coords].apply(lambda r: [(i[0],i[1]) for i in r[0]])
           .apply(pd.Series).stack()
           .reset_index(level=1).rename(columns={0:coords,"level_1":"point"})
           .join(df.drop(coords,1), how='left')).reset_index(level=0)

    df2[['lat','long']] = df2[coords].apply(pd.Series)
    json_records = df.reset_index().to_json(orient='records')
    arr = []
    arr = json.loads(json_records)

    labels = ['HAFMAP-468_v37']
    data = [len(df)]
    contextt = {
                'df_dict': df.to_dict(),
                'df_rec': df.to_dict(orient='records'),
                'labels':labels,
                'data':data,
                'my_map': m
                }

    return render(request, 'previous_map_report.html', contextt)

def compare(request):
    shp_dir = os.path.join(os.getcwd(),'media', 'shp')
    contents_1 = open(os.path.join(shp_dir, 'HAFMAP-468_v31_Demo.geojson')).read()
    data_1 = json.loads(contents_1)
    df_1 = pd.json_normalize(data_1["features"])
    contents_2 = open(os.path.join(shp_dir, 'HAFMAP-468_v37_Demo.geojson')).read()
    data_2 = json.loads(contents_2)
    df_2 = pd.json_normalize(data_2["features"])
    labels = ['HAFMAP-468_v31', 'HAFMAP-468_v37']
    data = [len(df_1), len(df_2)]
    contextt = {
                'labels':labels,
                'data':data
                }

    return render(request, 'compare.html', contextt)

def getMapReportPath(request):
    global v1path
    global v2path
    if request.method == 'POST':
        v1path = request.POST.get('V1')
        v2path = request.POST.get('V2')
    return render(request, 'current_map_report.html')
